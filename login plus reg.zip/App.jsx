import "./App.css";
import React from "react";
import { Switch, BrowserRouter as Router, Route } from "react-router-dom";
import RegistrationPageAfter from "./components/RegistrationPageAfter";
import LoginPageAfter from "./components/LoginPageAfter";

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/registration-page-after">
          <RegistrationPageAfter {...registrationPageAfterData} />
        </Route>
        <Route path="/:path(|login-page-after)">
          <LoginPageAfter {...loginPageAfterData} />
        </Route>
      </Switch>
    </Router>
  );
}

export default App;
const registrationPageAfterData = {
    getstarted: "Get Started",
    login: "Login",
    text1: "Already have an account?",
    bgclg: "/img/bgclg@1x.png",
    screen_Shot_14430229_At_5281: "/img/screen-shot-1443-02-29-at-5-28-2@2x.png",
    text2: <>Let’s End Boredom <br />Find The Best <br />Movies</>,
    spanText: <>Filmey © 2021<br /></>,
    spanText2: "",
    inputType: "text",
    inputPlaceholder: "Username",
    title: "Username",
    title2: "Region",
    name: "Riyadh",
    title3: "Gender",
    title4: "Female",
    title5: "Male",
    title6: "Birth date",
    phone: "06.12.1992",
    title7: "Which of these is your favorite movie genre?",
    title8: "Action",
    title9: "Horror",
    title10: "Drama",
    title11: "Other",
    title12: "Comedy",
};

const loginPageAfterData = {
    bgclg: "/img/bgclg@1x.png",
    screen_Shot_14430229_At_5282: "/img/screen-shot-1443-02-29-at-5-28-2@2x.png",
    welcomeBack: "WELCOME BACK!",
    text3: "Don’t have a account,",
    spanText: " ",
    spanText2: "Register",
    emailUsername: "Email / Username",
    inputType: "text",
    inputPlaceholder: "Username",
    password: "Password",
    inputType2: "password",
    inputPlaceholder2: "password",
    logIn: "Log In",
};

