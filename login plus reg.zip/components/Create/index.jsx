import React from "react";
import "./Create.css";

function Create() {
  return (
    <div className="create">
      <div className="overlap-group4">
        <div className="create-1 roboto-bold-white-28px">Create</div>
      </div>
    </div>
  );
}

export default Create;
