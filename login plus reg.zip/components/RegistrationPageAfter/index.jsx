import React from "react";
import { Link } from "react-router-dom";
import Email from "../Email";
import Password from "../Password";
import Create from "../Create";
import "./RegistrationPageAfter.css";

function RegistrationPageAfter(props) {
  const {
    getstarted,
    login,
    text1,
    bgclg,
    screen_Shot_14430229_At_5281,
    text2,
    spanText,
    spanText2,
    inputType,
    inputPlaceholder,
    title,
    title2,
    name,
    title3,
    title4,
    title5,
    title6,
    phone,
    title7,
    title8,
    title9,
    title10,
    title11,
    title12,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="registration-page-after screen">
        <div className="overlap-group14">
          <div className="br1"></div>
          <div className="overlap-group">
            <h1 className="getstarted">{getstarted}</h1>
            <Link to="/login-page-after">
              <div className="login">{login}</div>
            </Link>
            <div className="text-1">{text1}</div>
          </div>
          <img className="bg-clg" src={bgclg} />
          <img className="screen-shot14-02-29at528-1" src={screen_Shot_14430229_At_5281} />
          <div className="text-2">{text2}</div>
          <div className="copyright inter-light-bon-jour-35px">
            <span className="inter-light-bon-jour-35px">{spanText}</span>
            <span className="span1 inter-light-bon-jour-35px">{spanText2}</span>
          </div>
          <div className="overlap-group1-1">
            <div className="r1"></div>
            <input
              className="name roboto-normal-pink-swan-16px"
              name="name"
              placeholder={inputPlaceholder}
              type={inputType}
              required
            />
            <div className="title-1 nunito-normal-river-bed-18px">{title}</div>
          </div>
          <Email />
          <Password />
          <Create />
          <div className="region">
            <div className="title-2 nunito-normal-river-bed-18px">{title2}</div>
            <div className="overlap-group5">
              <div className="name-1 roboto-normal-pink-swan-16px">{name}</div>
              <img className="arrowdropdown" src="/img/arrow-drop-down@2x.svg" />
            </div>
          </div>
          <div className="gender">
            <div className="flex-col">
              <div className="title-3 nunito-normal-black-18px">{title3}</div>
              <div className="overlap-group7 border-2px-cardinal">
                <div className="ellipse-5 border-2px-cardinal"></div>
                <a href="#rectangle-54">
                  <div className="title-4 nunito-normal-river-bed-18px">{title4}</div>
                </a>
              </div>
            </div>
            <div className="overlap-group6 border-2px-cardinal">
              <div className="rectangle-57 border-2px-cardinal"></div>
              <div className="title-5 nunito-normal-river-bed-18px">{title5}</div>
              <div className="ellipse-6 border-2px-cardinal"></div>
            </div>
          </div>
          <div className="bd">
            <div className="title-6 nunito-normal-river-bed-18px">{title6}</div>
            <div className="overlap-group8">
              <div className="phone">{phone}</div>
            </div>
          </div>
          <div className="fav-genre">
            <div className="title-7 nunito-normal-black-18px">{title7}</div>
            <div className="flex-row">
              <div className="flex-col-1">
                <div className="overlap-group1">
                  <div className="rectangle border-2px-cardinal"></div>
                  <div className="title nunito-normal-river-bed-18px">{title8}</div>
                  <img className="rectangle-126" src="/img/rectangle-126@2x.svg" />
                </div>
                <div className="overlap-group10">
                  <div className="rectangle border-2px-cardinal"></div>
                  <div className="title nunito-normal-river-bed-18px">{title9}</div>
                  <img className="rectangle-126" src="/img/rectangle-126-3@2x.svg" />
                </div>
              </div>
              <div className="flex-col-2">
                <div className="overlap-group1">
                  <div className="rectangle border-2px-cardinal"></div>
                  <div className="title nunito-normal-river-bed-18px">{title10}</div>
                  <img className="rectangle-126" src="/img/rectangle-126-2@2x.svg" />
                </div>
                <div className="overlap-group9">
                  <div className="rectangle border-2px-cardinal"></div>
                  <div className="title nunito-normal-river-bed-18px">{title11}</div>
                  <img className="rectangle-126" src="/img/rectangle-126-4@2x.svg" />
                </div>
              </div>
              <div className="overlap-group11">
                <div className="rectangle-61 border-2px-cardinal"></div>
                <div className="title-8 nunito-normal-river-bed-18px">{title12}</div>
                <img className="rectangle-126" src="/img/rectangle-126-1@2x.svg" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default RegistrationPageAfter;
