import React from "react";
import { Link } from "react-router-dom";
import "./LoginPageAfter.css";

function LoginPageAfter(props) {
  const {
    bgclg,
    screen_Shot_14430229_At_5282,
    welcomeBack,
    text3,
    spanText,
    spanText2,
    emailUsername,
    inputType,
    inputPlaceholder,
    password,
    inputType2,
    inputPlaceholder2,
    logIn,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="login-page-after screen">
        <div className="overlap-group1-2">
          <div className="rectangle-1"></div>
          <img className="bg-clg-1" src={bgclg} />
          <img className="screen-shot14-02-29at528-2" src={screen_Shot_14430229_At_5282} />
          <div className="login-1">
            <div className="welcome-back">{welcomeBack}</div>
            <div className="flex-row-1">
              <div className="text-3">{text3}</div>
              <Link to="/registration-page-after">
                <div className="place">
                  <span className="span0-1">{spanText}</span>
                  <span className="span1-1">{spanText2}</span>
                </div>
              </Link>
            </div>
            <div className="input-field">
              <div className="username">
                <div className="email-username nunito-semi-bold-white-28px">{emailUsername}</div>
                <div className="frame-4 border-2px-chicago">
                  <input
                    className="name-2 roboto-normal-pink-swan-16px"
                    name="name"
                    placeholder={inputPlaceholder}
                    type={inputType}
                    required
                  />
                </div>
              </div>
              <div className="password-1">
                <div className="password-2 nunito-semi-bold-white-28px">{password}</div>
                <div className="frame-4-1 border-2px-chicago">
                  <input
                    className="name-3 roboto-normal-pink-swan-16px"
                    name="name"
                    placeholder={inputPlaceholder2}
                    type={inputType2}
                    required
                  />
                </div>
              </div>
              <div className="button">
                <div className="overlap-group-1">
                  <div className="log-in roboto-bold-white-28px">{logIn}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LoginPageAfter;
